# Contexto do Projeto RSDIS - Trabalhos 3.1 e 3.2 (Gazebo & TurtleBot3)

Este documento resume o estado atual do desenvolvimento, arquitetura dos pacotes e requisitos pendentes para continuidade no Claude.

---

## 1. Informações Gerais
- **Unidade Curricular:** Redes e Sistemas Distribuídos (RSDIS) - 1.º Ano de Mestrado (MEEC / ISEP).
- **Ambiente:** Ubuntu 24.04 LTS, **ROS 2 Jazzy**, Gazebo Sim (nova geração / gz-sim).
- **Robô:** TurtleBot3 Burger (`TURTLEBOT3_MODEL=burger`).
- **Workspace:** `~/ros2_ws` (código em `~/ros2_ws/src`).

---

## 2. Trabalho 3.1 (`rsdis_t3a`) - Estado: Código Concluído
- **Objetivo:** Exploração autónoma de um aspirador no cenário `turtlebot3_house` sem colisões.
- **Node Principal:** `src/robot_aspirador.cpp` (executável: `aspirador_node`).
  - Subscrição: `/scan` (`sensor_msgs/msg/LaserScan`).
  - Publicação: `/cmd_vel` (`geometry_msgs/msg/TwistStamped`).
  - Lógica: Comportamento reativo simples (setor frontal $[-30^\circ, +30^\circ]$, obstáculo a menos de 0.6 m); se detetar obstáculo, pára e roda no sítio.
  - Parede virtual (odometria, `/odom`): se sair da casa por uma porta, roda até ficar virado para o centro da casa e volta a entrar. Testado 6 min (2026-11-03): sem colisões e sempre dentro de casa.
- **Como Correr:**
  ```bash
  # Terminal 1:
  export TURTLEBOT3_MODEL=burger
  ros2 launch turtlebot3_gazebo turtlebot3_house.launch.py
  # Terminal 2:
  cd ~/ros2_ws && source install/setup.bash
  ros2 run rsdis_t3a aspirador_node
  ```

---

## 3. Trabalho 3.2 (`rsdis_t3b`) - Estado: Código e Mapa Concluídos
- **Objetivo:** No labirinto `turtlebot3_stage_4`:
  1. Exploração autónoma tipo aspirador sem colisões.
  2. Identificação de cilindros ($R \approx 0.12\text{ m}$) via LiDAR 2D (posição $(x,y)$, raio e área da base $\pi r^2 \approx 0.0452\text{ m}^2$).
  3. Mapeamento do cenário via SLAM.

### Ficheiros e Lógica:
- **`src/laser_subscritor.cpp` (Aspirador):**
  - Setor frontal $[-60^\circ, +60^\circ]$ (com ±30º raspava nas paredes de lado); distância de deteção afinada para **$0.30\text{ m}$** (evita colisões e permite passar nas portas); velocidade linear $0.25\text{ m/s}$ e rotação $-0.6\text{ rad/s}$.
- **`src/identificador_cilindro.cpp` (Deteção Simples de Cilindros):**
  - Usa o **Método da Largura e Isolamento** (simples, intuitivo e defensável):
    1. Deteta início e fim de objetos soltos através de saltos de distância no LiDAR (`diff > 0.15 m`).
    2. Mede a largura euclidiana entre as bordas ($0.16\text{ m} \le \text{largura} \le 0.28\text{ m}$, diâmetro real de $0.24\text{ m}$).
    3. Confirma isolamento no mapa do SLAM (rejeita quinas e pontas de divisórias).
    4. Converte a pose para o referencial `map` via TF2 e calcula a média móvel das deteções.
    5. Imprime no terminal: `🎯 [CILINDRO DETETADO] em (x, y) no mapa | Raio: 0.12 m | Área da base: 0.0452 m²`.
    6. Publica marcadores cor-de-laranja 3D para o RViz no tópico `/cilindros`.
- **`launch/trabalho.launch.py`:**
  - Lança o SLAM (`slam_toolbox` por defeito ou `cartographer`), o aspirador (`laser_sub`), o detetor (`identificador_cilindro`) e o RViz2.
- **`mapa/`:**
  - Mapa final do stage 4 já gerado e salvo: `mapa_stage4.pgm` e `mapa_stage4.yaml`.

---

## 4. O que Falta Fazer para a Entrega Final
1. **Trabalho 3.1:** Tirar 1 ou 2 screenshots do robô a navegar na casa do Gazebo (`turtlebot3_house`).
2. **Trabalho 3.2:** Gravar um pequeno vídeo ou screenshots da simulação no Stage 4 (robô no Gazebo, mapa a abrir no RViz e mensagens dos cilindros no terminal).
3. **Empacotamento:** pôr os screenshots em `rsdis_t3a/screenshots/` e `rsdis_t3b/screenshots/` e correr `bash ~/ros2_ws/criar_zips_t3.sh` (cria `src/Entregas_GitHub/Trabalho_3/GX_t3a.zip` e `GX_t3b.zip` sem build/install/log).
