#include <chrono>
#include <memory>

#include "rclcpp/rclcpp.hpp"
#include "sensor_msgs/msg/laser_scan.hpp"
#include "geometry_msgs/msg/twist_stamped.hpp"
#include "visualization_msgs/msg/marker_array.hpp"

using namespace std::chrono_literals; // para que isto serve

class LidarPublisher : public rclcpp::Node
{
public:
  LidarPublisher() : Node("laser_publicador")
  {
    publisher_= this->create_publisher<geometry_msgs::msg::TwistStamped>("cmd_vel", 10);

    auto timer_callback = [this]() -> void {
    auto msg = geometry_msgs::msg::TwistStamped();

    //mensagem TwistStamped: A twist with reference coordinate frame and timestamp.

    msg.header.stamp = this->get_clock()->now(); // colocar a hora diferente da do computador  
    msg.header.frame_id = "base_link";  // basa_link é o nome dado na norma 


    //mensagem Twist: Velocity in 3-dimensional free space broken into its linear and angular parts.

    msg.twist.linear.x = 0.2;
    msg.twist.angular.z = 0.0;
    

    RCLCPP_INFO(this->get_logger(), "A aspirar: a andar para a frente!");

     // Envia o comando para os motores
      this->publisher_->publish(msg);   
    };
    timer_ = this->create_wall_timer(1000ms, timer_callback);

    }
    private:
  rclcpp::TimerBase::SharedPtr timer_;
  rclcpp::Publisher<geometry_msgs::msg::TwistStamped>::SharedPtr publisher_;
};

int main(int argc, char * argv[])
{
  rclcpp::init(argc, argv);
  rclcpp::spin(std::make_shared<LidarPublisher>());
  rclcpp::shutdown();
  return 0;
}