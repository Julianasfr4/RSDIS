#include <chrono>
#include <memory>
#include <cmath>
#include <vector>

#include "rclcpp/rclcpp.hpp"
#include "sensor_msgs/msg/laser_scan.hpp"
#include "nav_msgs/msg/occupancy_grid.hpp"
#include "visualization_msgs/msg/marker_array.hpp"
#include "tf2_ros/buffer.hpp"
#include "tf2_ros/transform_listener.hpp"

using std::placeholders::_1;

// Um cilindro encontrado, com a posição no mapa
struct Cilindro
{
  double x;
  double y;
  int detecoes;      // quantas vezes já foi visto
  bool confirmado;   // já foi anunciado no terminal
};

class IdentificadorCilindro : public rclcpp::Node
{
public:
  IdentificadorCilindro()
  : Node("identificador_cilindro")
  {
    // Canal para receber as leituras do sensor LiDAR 2D
    scan_sub_ = this->create_subscription<sensor_msgs::msg::LaserScan>(
      "scan", rclcpp::SensorDataQoS(), std::bind(&IdentificadorCilindro::scan_callback, this, _1));

    // Canal para receber o mapa construído pelo SLAM
    mapa_sub_ = this->create_subscription<nav_msgs::msg::OccupancyGrid>(
      "map", 1, [this](const nav_msgs::msg::OccupancyGrid::SharedPtr m) {mapa_ = m;});

    // Canal para mostrar os cilindros no RViz
    marcadores_pub_ = this->create_publisher<visualization_msgs::msg::MarkerArray>("cilindros", 10);

    // TF: diz onde está o robô no mapa
    tf_buffer_ = std::make_unique<tf2_ros::Buffer>(this->get_clock());
    tf_listener_ = std::make_shared<tf2_ros::TransformListener>(*tf_buffer_);

    RCLCPP_INFO(this->get_logger(), "Detetor de Cilindros Iniciado! À procura de cilindros...");
  }

private:
  // Distância medida pelo raio i. Se não bateu em nada (inf), conta como muito longe.
  float distancia(const sensor_msgs::msg::LaserScan & msg, int i)
  {
    float r = msg.ranges[i];
    if (!std::isfinite(r) || r > msg.range_max) {
      return 10.0;
    }
    return r;
  }

  void scan_callback(const sensor_msgs::msg::LaserScan::SharedPtr msg)
  {
    // Posição (rx, ry) e orientação (yaw) do robô no mapa
    geometry_msgs::msg::TransformStamped t;
    try {
      t = tf_buffer_->lookupTransform("map", msg->header.frame_id, tf2::TimePointZero);
    } catch (const tf2::TransformException &) {
      return; // ainda não há mapa
    }
    double rx = t.transform.translation.x;
    double ry = t.transform.translation.y;
    const auto & q = t.transform.rotation;
    double yaw = std::atan2(2.0 * (q.w * q.z + q.x * q.y), 1.0 - 2.0 * (q.y * q.y + q.z * q.z));

    const int n = msg->ranges.size();
    float threshold = 0.15; // salto mínimo entre dois raios seguidos (15 cm)
    bool em_cilindro = false;
    int inicio = 0;

    for (int i = 1; i < n; i++)
    {
      float diff = distancia(*msg, i) - distancia(*msg, i - 1);

      // 1. COMEÇOU UM OBJETO (salto para a frente: o raio bateu mais perto)
      if (diff < -threshold) {
        em_cilindro = true;
        inicio = i;
      }
      // 2. ACABOU O OBJETO (salto para trás: o raio seguinte passa-lhe ao lado e vai mais longe)
      else if (em_cilindro && diff > threshold) {
        em_cilindro = false;
        int fim = i - 1;
        int pontos = fim - inicio + 1;

        // Ignora objetos com poucos pontos (ruído) ou muito longe (medição pouco precisa)
        float dist = distancia(*msg, (inicio + fim) / 2);
        if (pontos < 5 || dist > 2.5) {
          continue;
        }

        // Coordenadas (X, Y) do primeiro e do último ponto do objeto
        float ang_ini = msg->angle_min + inicio * msg->angle_increment;
        float ang_fim = msg->angle_min + fim * msg->angle_increment;
        float x1 = distancia(*msg, inicio) * std::cos(ang_ini);
        float y1 = distancia(*msg, inicio) * std::sin(ang_ini);
        float x2 = distancia(*msg, fim) * std::cos(ang_fim);
        float y2 = distancia(*msg, fim) * std::sin(ang_fim);

        // A largura do objeto é o diâmetro do cilindro. Os raios estão espaçados de 1º, por isso
        // os pontos das bordas ficam um pouco para dentro: soma-se o espaço entre dois raios.
        float largura = std::hypot(x2 - x1, y2 - y1) + dist * msg->angle_increment;
        float raio = largura / 2.0;
        float area = M_PI * raio * raio;

        // O teste da professora: área da base de um cilindro
        if (area < 0.03 || area > 0.09) {
          continue;
        }

        // Centro do cilindro: na direção do meio do objeto, um raio atrás da superfície vista
        float ang = (ang_ini + ang_fim) / 2.0;
        double cx = (dist + raio) * std::cos(ang);
        double cy = (dist + raio) * std::sin(ang);

        // Passar do referencial do robô para o referencial do mapa (rodar e somar a posição do robô)
        double mx = rx + cx * std::cos(yaw) - cy * std::sin(yaw);
        double my = ry + cx * std::sin(yaw) + cy * std::cos(yaw);

        registar_cilindro(mx, my, raio, area);
      }
    }
    publicar_marcadores();
  }

  // Conta quantas vezes cada cilindro é visto e anuncia-o quando tiver a certeza
  void registar_cilindro(double mx, double my, float raio, float area)
  {
    for (auto & c : cilindros_) {
      // A menos de 50 cm de um cilindro já visto: é o mesmo
      if (std::hypot(c.x - mx, c.y - my) < 0.50) {
        c.detecoes++;
        // A posição é a média de todas as vezes que foi visto
        c.x += (mx - c.x) / c.detecoes;
        c.y += (my - c.y) / c.detecoes;
        if (!c.confirmado && c.detecoes >= 15 && isolado_no_mapa(c.x, c.y)) {
          c.confirmado = true;
          RCLCPP_INFO(this->get_logger(),
            "🎯 [CILINDRO DETETADO] em (%.2f, %.2f) no mapa | Raio: %.2f m | Área da base: %.4f m²",
            c.x, c.y, raio, area);
        }
        return;
      }
    }
    cilindros_.push_back({mx, my, 1, false});
  }

  // Um cilindro está solto no chão: no mapa, entre 20 e 30 cm do centro, não há nada.
  // Na ponta de uma tábua o resto da tábua aparece aí como células ocupadas (pretas).
  bool isolado_no_mapa(double cx, double cy)
  {
    if (!mapa_) {
      return false; // ainda sem mapa: espera que o SLAM o publique
    }
    const auto & info = mapa_->info;
    int ocupadas = 0;
    for (unsigned int j = 0; j < info.height; j++) {
      for (unsigned int i = 0; i < info.width; i++) {
        // centro da célula (i, j) em metros
        double x = info.origin.position.x + (i + 0.5) * info.resolution;
        double y = info.origin.position.y + (j + 0.5) * info.resolution;
        double d = std::hypot(x - cx, y - cy);
        if (d > 0.20 && d < 0.30 && mapa_->data[j * info.width + i] > 50) {
          ocupadas++;
        }
      }
    }
    return ocupadas <= 1;
  }

  // Desenha no RViz um cilindro cor de laranja em cada cilindro confirmado
  void publicar_marcadores()
  {
    visualization_msgs::msg::MarkerArray lista;
    int id = 0;
    for (const auto & c : cilindros_) {
      if (!c.confirmado) {
        continue;
      }
      visualization_msgs::msg::Marker m;
      m.header.frame_id = "map";
      m.ns = "cilindros";
      m.id = id++;
      m.type = visualization_msgs::msg::Marker::CYLINDER;
      m.pose.position.x = c.x;
      m.pose.position.y = c.y;
      m.pose.position.z = 0.25;
      m.pose.orientation.w = 1.0;
      m.scale.x = 0.24;  // diâmetro
      m.scale.y = 0.24;
      m.scale.z = 0.5;   // altura
      m.color.r = 1.0;
      m.color.g = 0.5;
      m.color.a = 0.8;
      lista.markers.push_back(m);
    }
    marcadores_pub_->publish(lista);
  }

  rclcpp::Subscription<sensor_msgs::msg::LaserScan>::SharedPtr scan_sub_;
  rclcpp::Subscription<nav_msgs::msg::OccupancyGrid>::SharedPtr mapa_sub_;
  nav_msgs::msg::OccupancyGrid::SharedPtr mapa_;
  rclcpp::Publisher<visualization_msgs::msg::MarkerArray>::SharedPtr marcadores_pub_;
  std::unique_ptr<tf2_ros::Buffer> tf_buffer_;
  std::shared_ptr<tf2_ros::TransformListener> tf_listener_;
  std::vector<Cilindro> cilindros_;
};

int main(int argc, char * argv[])
{
  rclcpp::init(argc, argv);
  rclcpp::spin(std::make_shared<IdentificadorCilindro>());
  rclcpp::shutdown();
  return 0;
}
