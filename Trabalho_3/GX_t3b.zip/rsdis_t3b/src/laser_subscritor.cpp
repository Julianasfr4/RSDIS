#include <chrono>
#include <memory>
#include <algorithm>
#include <cmath>

#include "rclcpp/rclcpp.hpp"
#include "sensor_msgs/msg/laser_scan.hpp"
#include "geometry_msgs/msg/twist_stamped.hpp"

using namespace std::chrono_literals;

class LaserSub : public rclcpp::Node
{
public:
  LaserSub()
  : Node("laser_sub"), obstacle_detected_(false)
  {
    publisher_ = this->create_publisher<geometry_msgs::msg::TwistStamped>("cmd_vel", 10);

    subscriber_ = this->create_subscription<sensor_msgs::msg::LaserScan>(
      "scan", rclcpp::SensorDataQoS(),
      std::bind(&LaserSub::scan_callback, this, std::placeholders::_1));

    // Ciclo de controlo a cada 100ms (10 Hz)
    timer_ = this->create_wall_timer(
      100ms, std::bind(&LaserSub::timer_callback, this));

    RCLCPP_INFO(this->get_logger(), "Aspirador TurtleBot3 Iniciado! Modo exploração simples ativo.");
  }

private:
  void scan_callback(const sensor_msgs::msg::LaserScan::SharedPtr msg)
  {
    if (msg->ranges.empty()) {
      return;
    }

    float min_dist = 100.0;
    const int n = static_cast<int>(msg->ranges.size());

    // Setor frente-esquerda: 0º a 60º (também vê as paredes de lado, para não raspar)
    for (int i = 0; i <= 60 && i < n; i++) {
      float r = msg->ranges[i];
      if (std::isfinite(r) && r > 0.05 && r < min_dist) {
        min_dist = r;
      }
    }

    // Setor frente-direita: 300º a 359º
    for (int i = std::max(0, n - 60); i < n; i++) {
      float r = msg->ranges[i];
      if (std::isfinite(r) && r > 0.05 && r < min_dist) {
        min_dist = r;
      }
    }

    // Se houver obstáculo a menos de 30 cm à frente ou de lado, ativa rotação
    obstacle_detected_ = (min_dist < 0.30);
  }

  void timer_callback()
  {
    auto twist_msg = geometry_msgs::msg::TwistStamped();
    twist_msg.header.stamp = this->now();
    twist_msg.header.frame_id = "base_link";

    if (obstacle_detected_) {
      // Parar e rodar no sítio até o caminho frontal estar desobstruído
      twist_msg.twist.linear.x = 0.0;
      twist_msg.twist.angular.z = -0.6;
    } else {
      // Caminho livre: avançar com velocidade constante
      twist_msg.twist.linear.x = 0.25;
      twist_msg.twist.angular.z = 0.0;
    }

    publisher_->publish(twist_msg);
  }

  rclcpp::Publisher<geometry_msgs::msg::TwistStamped>::SharedPtr publisher_;
  rclcpp::Subscription<sensor_msgs::msg::LaserScan>::SharedPtr subscriber_;
  rclcpp::TimerBase::SharedPtr timer_;
  bool obstacle_detected_;
};

int main(int argc, char * argv[])
{
  rclcpp::init(argc, argv);
  rclcpp::spin(std::make_shared<LaserSub>());
  rclcpp::shutdown();
  return 0;
}
