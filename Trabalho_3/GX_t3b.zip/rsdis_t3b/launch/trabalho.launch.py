"""Trabalho 3.2: aspirador + identificador de cilindros + construção do mapa (SLAM).

Antes, noutro terminal, abrir o cenário:
  ros2 launch turtlebot3_gazebo turtlebot3_dqn_stage4.launch.py

Para correr com SLAM Toolbox (Opção 2 - Padrão moderno do ROS 2):
  ros2 launch rsdis_t3b trabalho.launch.py

Para correr com Cartographer (Opção 1):
  ros2 launch rsdis_t3b trabalho.launch.py slam_engine:=cartographer
"""

import os

from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, IncludeLaunchDescription
from launch.conditions import IfCondition
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import EqualsSubstitution, LaunchConfiguration
from launch_ros.actions import Node


def generate_launch_description():
    slam_engine = LaunchConfiguration('slam_engine')
    frame_fixo = LaunchConfiguration('frame_fixo')

    # 1. Opção SLAM Toolbox (Opção 2)
    slam_toolbox = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(os.path.join(
            get_package_share_directory('slam_toolbox'),
            'launch', 'online_async_launch.py')),
        launch_arguments={'use_sim_time': 'True'}.items(),
        condition=IfCondition(EqualsSubstitution(slam_engine, 'slam_toolbox')),
    )

    # 2. Opção Cartographer (Opção 1)
    cartographer = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(os.path.join(
            get_package_share_directory('turtlebot3_cartographer'),
            'launch', 'cartographer.launch.py')),
        launch_arguments={'use_sim_time': 'True'}.items(),
        condition=IfCondition(EqualsSubstitution(slam_engine, 'cartographer')),
    )

    # RViz2 para o SLAM Toolbox (o Cartographer já abre o seu próprio RViz)
    rviz_config = os.path.join(
        get_package_share_directory('rsdis_t3b'),
        'rviz', 'trabalho.rviz')

    rviz_node = Node(
        package='rviz2',
        executable='rviz2',
        name='rviz2',
        arguments=['-d', rviz_config],
        parameters=[{'use_sim_time': True}],
        output='screen',
        condition=IfCondition(EqualsSubstitution(slam_engine, 'slam_toolbox')),
    )

    # 3. Nó do Aspirador (exploração autónoma)
    aspirador = Node(
        package='rsdis_t3b',
        executable='laser_subscritor',
        name='laser_sub',
        output='screen',
        parameters=[{'use_sim_time': True}],
    )

    # 4. Nó Identificador de Cilindros (LiDAR 2D)
    cilindros = Node(
        package='rsdis_t3b',
        executable='identificador_cilindro',
        name='identificador_cilindro',
        output='screen',
        parameters=[{'use_sim_time': True, 'frame_fixo': frame_fixo}],
    )

    return LaunchDescription([
        DeclareLaunchArgument(
            'slam_engine',
            default_value='slam_toolbox',
            description='Motor de SLAM a usar: "slam_toolbox" (Opção 2) ou "cartographer" (Opção 1)'),
        DeclareLaunchArgument(
            'frame_fixo',
            default_value='map',
            description='Referencial fixo global (map)'),
        slam_toolbox,
        rviz_node,
        cartographer,
        aspirador,
        cilindros,
    ])
