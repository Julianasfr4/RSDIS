# rsdis_t3b

Package ROS 2 (Jazzy) para o Trabalho 3.2: exploração autónoma tipo aspirador, identificação de cilindros com o LiDAR 2D e construção do mapa.

| Requisito do enunciado | Node / ferramenta |
|---|---|
| 1. Exploração autónoma sem colisões | `laser_subscritor` (avança; com obstáculo a menos de 30 cm à frente roda no sítio) |
| 2. Identificação dos cilindros com LiDAR 2D | `identificador_cilindro` (saltos do LiDAR + largura/área + confirmação no mapa) |
| 3. Construção do mapa | SLAM Toolbox (por defeito) ou Cartographer + `map_saver_cli` |

## Compilar

```bash
cd ~/ros2_ws/src
# copiar esta pasta para aqui
cd ~/ros2_ws
colcon build --packages-select rsdis_t3b
source install/setup.bash
```

## Correr

```bash
export TURTLEBOT3_MODEL=burger

# Terminal 1: cenário da Figura 1 (stage 4)
ros2 launch turtlebot3_gazebo turtlebot3_dqn_stage4.launch.py

# Terminal 2: aspirador + cilindros + SLAM Toolbox + RViz
ros2 launch rsdis_t3b trabalho.launch.py
# (ou com o Cartographer: ros2 launch rsdis_t3b trabalho.launch.py slam_engine:=cartographer)

# Os cilindros encontrados aparecem no terminal 2 ([CILINDRO DETETADO] em (x, y) no mapa ...)
# e no RViz como cilindros cor de laranja (tópico /cilindros).

# Terminal 3: quando o mapa estiver completo, guardá-lo
ros2 run nav2_map_server map_saver_cli -f ~/ros2_ws/src/rsdis_t3b/mapa/mapa_stage4
```

## Como funciona

**Exploração (`laser_subscritor`)**: verifica a distância mínima no setor frontal (±60º, para ver também as paredes de lado). Com caminho livre avança a 0,25 m/s; com um obstáculo a menos de 30 cm pára e roda no sítio para a direita até a frente ficar livre.

**Cilindros (`identificador_cilindro`)**:
1. Percorre os 360 raios do LiDAR. Um salto para a frente (> 15 cm, o raio bate mais perto) marca o início de um objeto; um salto para trás (o raio seguinte passa ao lado e vai mais longe) marca o fim. Assim só ficam objetos soltos, com espaço livre dos dois lados.
2. Ignora objetos com menos de 5 pontos ou a mais de 2,5 m.
3. Mede a largura entre o primeiro e o último ponto, mais o espaço entre dois raios (os pontos das bordas ficam um pouco para dentro): raio = largura / 2, área = π·raio². Aceita se a área estiver entre 0,03 e 0,09 m² (teste da professora).
4. Calcula o centro do cilindro e passa-o para o referencial `map` com o TF (posição e orientação do robô).
5. Conta quantas vezes cada cilindro é visto (deteções a menos de 50 cm são o mesmo). À 15.ª vez, se estiver **isolado no mapa** (sem células ocupadas entre 20 e 30 cm do centro), escreve no terminal a posição (média de todas as deteções), o raio e a área da base, e desenha-o no RViz. Este último teste rejeita as pontas das tábuas, que têm a mesma largura de um cilindro mas estão ligadas ao resto da tábua.

