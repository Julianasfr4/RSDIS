#include "rclcpp/rclcpp.hpp"
#include "sensor_msgs/msg/laser_scan.hpp"
#include "nav_msgs/msg/odometry.hpp"
#include "geometry_msgs/msg/twist_stamped.hpp"

// Limites da casa medidos a partir do sítio onde o robô começa (odometria)
const double X_MIN = -5.2, X_MAX = 9.2;
const double Y_MIN = -4.5, Y_MAX = 5.5;

class RobotAspirador : public rclcpp::Node {
public:
  RobotAspirador() : Node("robot_aspirador"), obstacle_detected_(false) {
    publisher_ = this->create_publisher<geometry_msgs::msg::TwistStamped>("cmd_vel", 10);
    subscriber_ = this->create_subscription<sensor_msgs::msg::LaserScan>(
      "scan", 10, std::bind(&RobotAspirador::scan_callback, this, std::placeholders::_1));
    odom_sub_ = this->create_subscription<nav_msgs::msg::Odometry>(
      "odom", 10, std::bind(&RobotAspirador::odom_callback, this, std::placeholders::_1));
    timer_ = this->create_wall_timer(std::chrono::milliseconds(100), std::bind(&RobotAspirador::timer_callback, this));
    RCLCPP_INFO(this->get_logger(), "Aspirador Iniciado! A limpar a casa...");
  }

private:
  void scan_callback(const sensor_msgs::msg::LaserScan::SharedPtr msg) {
    float min_dist = 100.0;
    for (int i = 0; i <= 30; i++) {
      if (msg->ranges[i] > 0.01 && msg->ranges[i] < min_dist) min_dist = msg->ranges[i];
    }
    for (int i = 330; i < 360; i++) {
      if (msg->ranges[i] > 0.01 && msg->ranges[i] < min_dist) min_dist = msg->ranges[i];
    }
    obstacle_detected_ = (min_dist < 0.6);
  }

  // Guarda a posição (x, y) do robô, dada pela odometria das rodas
  void odom_callback(const nav_msgs::msg::Odometry::SharedPtr msg) {
    x_ = msg->pose.pose.position.x;
    y_ = msg->pose.pose.position.y;
  }

  void timer_callback() {
    auto twist_msg = geometry_msgs::msg::TwistStamped();
    twist_msg.header.stamp = this->now();
    twist_msg.header.frame_id = "base_link";

    // Se saiu de casa (por uma porta), dá meia volta: roda 180º (63 ciclos de 0.1 s a 0.5 rad/s)
    bool fora_de_casa = x_ < X_MIN || x_ > X_MAX || y_ < Y_MIN || y_ > Y_MAX;
    if (fora_de_casa && !a_voltar_) {
      a_voltar_ = true;
      meia_volta_ = 63;
    }
    if (!fora_de_casa) {
      a_voltar_ = false;  // já está dentro de casa outra vez
    }

    if (meia_volta_ > 0) {
      meia_volta_--;
      twist_msg.twist.linear.x = 0.0;
      twist_msg.twist.angular.z = -0.5;
    } else if (obstacle_detected_) {
      twist_msg.twist.linear.x = 0.0;
      twist_msg.twist.angular.z = -0.5;
    } else {
      twist_msg.twist.linear.x = 0.25;
      twist_msg.twist.angular.z = 0.0;
    }
    publisher_->publish(twist_msg);
  }

  rclcpp::Publisher<geometry_msgs::msg::TwistStamped>::SharedPtr publisher_;
  rclcpp::Subscription<sensor_msgs::msg::LaserScan>::SharedPtr subscriber_;
  rclcpp::Subscription<nav_msgs::msg::Odometry>::SharedPtr odom_sub_;
  rclcpp::TimerBase::SharedPtr timer_;
  bool obstacle_detected_;
  double x_ = 0.0, y_ = 0.0;
  bool a_voltar_ = false;
  int meia_volta_ = 0;
};

int main(int argc, char * argv[]) {
  rclcpp::init(argc, argv);
  rclcpp::spin(std::make_shared<RobotAspirador>());
  rclcpp::shutdown();
  return 0;
}
