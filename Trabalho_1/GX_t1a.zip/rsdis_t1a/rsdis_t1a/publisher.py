import rclpy
from rclpy.node import Node
from std_msgs.msg import Float32

class Publisher(Node):
    def __init__(self):
        super().__init__('node_1')
        self.publisher_ = self.create_publisher(Float32, 'topic_a', 10)
        timer_period = 1.0 / 50.0  # 50 Hz
        self.timer = self.create_timer(timer_period, self.timer_callback)
        self.count = 0.0

    def timer_callback(self):
        msg = Float32()
        msg.data = self.count
        self.publisher_.publish(msg)
        self.get_logger().info('Publishing: "%f"' % msg.data)
        self.count += 1.0

def main(args=None):
    rclpy.init(args=args)
    publisher = Publisher()
    rclpy.spin(publisher)
    publisher.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
