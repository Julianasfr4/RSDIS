import rclpy
from rclpy.node import Node
from std_msgs.msg import Float32

class Subscriber(Node):
    def __init__(self):
        super().__init__('node_2')
        self.subscription = self.create_subscription(
            Float32,
            'topic_a',
            self.listener_callback,
            10)
        self.subscription  # prevent unused variable warning

    def listener_callback(self, msg):
        self.get_logger().info('I heard: "%f"' % msg.data)

def main(args=None):
    rclpy.init(args=args)
    subscriber = Subscriber()
    rclpy.spin(subscriber)
    subscriber.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
