#include "ros/ros.h"
#include "std_msgs/Float32.h"

int main(int argc, char **argv)
{
    ros::init(argc, argv, "float_publisher");

    ros::NodeHandle nh;

    ros::Publisher pub =
        nh.advertise<std_msgs::Float32>("float_topic", 10);

    // Frequência de 50 Hz
    ros::Rate rate(50);

    while (ros::ok())
    {
        std_msgs::Float32 msg;

        msg.data = 0.1f;

        pub.publish(msg);

        ROS_INFO("Publishing: %f", msg.data);

        ros::spinOnce();

        rate.sleep();
    }

    return 0;
}