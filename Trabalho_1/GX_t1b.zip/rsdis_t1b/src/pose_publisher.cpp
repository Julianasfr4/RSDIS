#include <chrono>
#include "rclcpp/rclcpp.hpp"
#include "geometry_msgs/msg/pose.hpp"

using namespace std::chrono_literals;

class PosePublisher : public rclcpp::Node {
public:
  PosePublisher() : Node("pose_publisher") {
    publisher_ = this->create_publisher<geometry_msgs::msg::Pose>("pose_topic", 10);
    
    // O enunciado pede 1 Hz, que corresponde exatamente a 1 segundo (1000ms)
    timer_ = this->create_wall_timer(1000ms, std::bind(&PosePublisher::timer_callback, this));
  }
private:
  void timer_callback() {
    auto message = geometry_msgs::msg::Pose();
    
    // O enunciado obriga a ter TODOS os campos preenchidos
    // 1. Posição no espaço 3D (X, Y, Z)
    message.position.x = 1.5;
    message.position.y = 2.0;
    message.position.z = 0.5;
    
    // 2. Orientação (Quaterniões - Rotação no espaço 3D)
    message.orientation.x = 0.0;
    message.orientation.y = 0.0;
    message.orientation.z = 0.707;
    message.orientation.w = 0.707;
    
    RCLCPP_INFO(this->get_logger(), "A publicar Pose a 1Hz -> X: %.1f, Y: %.1f", message.position.x, message.position.y);
    publisher_->publish(message);
  }
  rclcpp::TimerBase::SharedPtr timer_;
  rclcpp::Publisher<geometry_msgs::msg::Pose>::SharedPtr publisher_;
};

int main(int argc, char * argv[]) {
  rclcpp::init(argc, argv);
  rclcpp::spin(std::make_shared<PosePublisher>());
  rclcpp::shutdown();
  return 0;
}
