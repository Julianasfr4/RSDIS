#include <memory>
#include "rclcpp/rclcpp.hpp"
#include "geometry_msgs/msg/pose.hpp"

class PoseSubscriber : public rclcpp::Node {
public:
  PoseSubscriber() : Node("pose_subscriber") {
    subscription_ = this->create_subscription<geometry_msgs::msg::Pose>(
      "pose_topic", 10, std::bind(&PoseSubscriber::topic_callback, this, std::placeholders::_1));
  }
private:
  void topic_callback(const geometry_msgs::msg::Pose::SharedPtr msg) const {
    RCLCPP_INFO(this->get_logger(), "Recebi -> Posição: (%.1f, %.1f, %.1f) | Orientação: (%.3f, %.3f, %.3f, %.3f)", 
                msg->position.x, msg->position.y, msg->position.z,
                msg->orientation.x, msg->orientation.y, msg->orientation.z, msg->orientation.w);
  }
  rclcpp::Subscription<geometry_msgs::msg::Pose>::SharedPtr subscription_;
};

int main(int argc, char * argv[]) {
  rclcpp::init(argc, argv);
  rclcpp::spin(std::make_shared<PoseSubscriber>());
  rclcpp::shutdown();
  return 0;
}
