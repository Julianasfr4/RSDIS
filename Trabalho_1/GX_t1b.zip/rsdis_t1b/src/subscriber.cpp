#include "ros/ros.h"
#include "geometry_msgs/Pose.h"

void poseCallback(const geometry_msgs::Pose::ConstPtr& msg)
{
    ROS_INFO(
        "I heard Pose: position=(%.2f, %.2f, %.2f), "
        "orientation=(%.2f, %.2f, %.2f, %.2f)",
        msg->position.x,
        msg->position.y,
        msg->position.z,
        msg->orientation.x,
        msg->orientation.y,
        msg->orientation.z,
        msg->orientation.w
    );
}

int main(int argc, char **argv)
{
    ros::init(argc, argv, "pose_subscriber");

    ros::NodeHandle nh;

    ros::Subscriber sub =
        nh.subscribe("pose_topic", 10, poseCallback);

    ros::spin();

    return 0;
}