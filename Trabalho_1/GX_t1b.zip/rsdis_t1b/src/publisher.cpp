#include "ros/ros.h"
#include "geometry_msgs/Pose.h"

int main(int argc, char **argv)
{
    ros::init(argc, argv, "pose_publisher");

    ros::NodeHandle nh;

    ros::Publisher pub =
        nh.advertise<geometry_msgs::Pose>("pose_topic", 10);

    // Publicar uma mensagem por segundo
    ros::Rate rate(1);

    while (ros::ok())
    {
        geometry_msgs::Pose msg;

        // Posição
        msg.position.x = 1.0;
        msg.position.y = 2.0;
        msg.position.z = 3.0;

        // Orientação (quaternion)
        msg.orientation.x = 0.0;
        msg.orientation.y = 0.0;
        msg.orientation.z = 0.0;
        msg.orientation.w = 1.0;

        pub.publish(msg);

        ROS_INFO(
            "Publishing Pose: position=(%.2f, %.2f, %.2f), "
            "orientation=(%.2f, %.2f, %.2f, %.2f)",
            msg.position.x,
            msg.position.y,
            msg.position.z,
            msg.orientation.x,
            msg.orientation.y,
            msg.orientation.z,
            msg.orientation.w
        );

        ros::spinOnce();
        rate.sleep();
    }

    return 0;
}