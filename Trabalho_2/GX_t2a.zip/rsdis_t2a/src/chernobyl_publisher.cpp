#include <chrono>
#include <memory>
#include <string>

#include "rclcpp/rclcpp.hpp"
#include "rsdis_t2_interfaces/msg/chernobyl_data.hpp"

using namespace std::chrono_literals;

/* This example creates a subclass of Node and uses a fancy C++11 lambda
* function to shorten the callback syntax, at the expense of making the
* code somewhat more difficult to understand at first glance. */

class ChernobylPublisher : public rclcpp::Node
{
public:
  ChernobylPublisher()
  : Node("chernobyl_publisher"), count_(0)
  {
    publisher_ = this->create_publisher<rsdis_t2_interfaces::msg::ChernobylData>("topic", 10);
    auto timer_callback =
      [this]() -> void {
       
           auto message = rsdis_t2_interfaces::msg::ChernobylData();
        // 1. O Carimbo de Tempo
        message.header.stamp = this->now();
        message.header.frame_id = "chernobyl_frame";
        // Gera valores aleatórios escalados para limites realistas
        message.radiation = ((float)rand() / RAND_MAX) * 15.0; 
        message.gps.latitude = (((float)rand() / RAND_MAX) * 180.0) - 90.0;
        message.gps.longitude = (((float)rand() / RAND_MAX) * 360.0) - 180.0;
        message.temperature.temperature = (((float)rand() / RAND_MAX) * 60.0) - 20.0;
        message.gps.altitude = ((float)rand() / RAND_MAX) * 300.0;
        message.humidity.relative_humidity = ((float)rand() / RAND_MAX) * 100.0;
        
       RCLCPP_INFO(this->get_logger(), 
     "A publicar -> Radiação: %.2f | Temperatura: %.2f | Humidade: %.2f | GPS: (%.4f, %.4f)", 
     message.radiation, 
     message.temperature.temperature, 
     message.humidity.relative_humidity, 
     message.gps.latitude, 
     message.gps.longitude
);
        this->publisher_->publish(message);
      };
    timer_ = this->create_wall_timer(1000ms, timer_callback);
  }

private:
  rclcpp::TimerBase::SharedPtr timer_;
  rclcpp::Publisher<rsdis_t2_interfaces::msg::ChernobylData>::SharedPtr publisher_;
  size_t count_;
};

int main(int argc, char * argv[])
{
  rclcpp::init(argc, argv);
  rclcpp::spin(std::make_shared<ChernobylPublisher>());
  rclcpp::shutdown();
  return 0;
}