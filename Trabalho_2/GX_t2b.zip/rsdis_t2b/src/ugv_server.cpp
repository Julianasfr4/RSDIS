#include <memory>
#include <cmath>
#include "rclcpp/rclcpp.hpp"

// Importar as 4 interfaces
#include "rsdis_t2_interfaces/srv/deg_to_rad.hpp"
#include "rsdis_t2_interfaces/srv/rad_to_deg.hpp"
#include "rsdis_t2_interfaces/srv/g2_ecef.hpp"
#include "rsdis_t2_interfaces/srv/ecef2_g.hpp"

const double kSemimajorAxis = 6378137.0;
const double kSemiminorAxis = 6356752.3142;
const double kFirstEccentricitySquared = 6.69437999014 * 0.001;
const double kSecondEccentricitySquared = 6.73949674228 * 0.001;

class UGVServer : public rclcpp::Node
{
public:
  UGVServer() : Node("ugv")
  {
    d2r_service_ = this->create_service<rsdis_t2_interfaces::srv::DegToRad>(
      "d2r", std::bind(&UGVServer::handle_d2r, this, std::placeholders::_1, std::placeholders::_2));
      
    r2d_service_ = this->create_service<rsdis_t2_interfaces::srv::RadToDeg>(
      "r2d", std::bind(&UGVServer::handle_r2d, this, std::placeholders::_1, std::placeholders::_2));

    g2ecef_service_ = this->create_service<rsdis_t2_interfaces::srv::G2Ecef>(
      "g2ecef", std::bind(&UGVServer::handle_g2ecef, this, std::placeholders::_1, std::placeholders::_2));

    ecef2g_service_ = this->create_service<rsdis_t2_interfaces::srv::Ecef2G>(
      "ecef2g", std::bind(&UGVServer::handle_ecef2g, this, std::placeholders::_1, std::placeholders::_2));
      
    RCLCPP_INFO(this->get_logger(), "Robô UGV pronto! À escuta de contas para fazer...");
  }

private:
  void handle_d2r(const std::shared_ptr<rsdis_t2_interfaces::srv::DegToRad::Request> request,
                        std::shared_ptr<rsdis_t2_interfaces::srv::DegToRad::Response> response)
  {
    response->graus = request->radianos * (180.0 / M_PI);
    RCLCPP_INFO(this->get_logger(), "[D2R] Convertido: %.2f rads -> %.2f graus", request->radianos, response->graus);
  }

  void handle_r2d(const std::shared_ptr<rsdis_t2_interfaces::srv::RadToDeg::Request> request,
                        std::shared_ptr<rsdis_t2_interfaces::srv::RadToDeg::Response> response)
  {
    response->radianos = request->graus * (M_PI / 180.0);
    RCLCPP_INFO(this->get_logger(), "[R2D] Convertido: %.2f graus -> %.2f rads", request->graus, response->radianos);
  }

  void handle_g2ecef(const std::shared_ptr<rsdis_t2_interfaces::srv::G2Ecef::Request> request,
                           std::shared_ptr<rsdis_t2_interfaces::srv::G2Ecef::Response> response)
  {
    double lat_rad = request->latitude * (M_PI / 180.0);
    double lon_rad = request->longitude * (M_PI / 180.0);
    double xi = std::sqrt(1 - kFirstEccentricitySquared * std::sin(lat_rad) * std::sin(lat_rad));
    
    response->x = (kSemimajorAxis / xi + request->altitude) * std::cos(lat_rad) * std::cos(lon_rad);
    response->y = (kSemimajorAxis / xi + request->altitude) * std::cos(lat_rad) * std::sin(lon_rad);
    response->z = (kSemimajorAxis / xi * (1 - kFirstEccentricitySquared) + request->altitude) * std::sin(lat_rad);
    
    RCLCPP_INFO(this->get_logger(), "[G2ECEF] Convertido GPS para XYZ com sucesso.");
  }

  void handle_ecef2g(const std::shared_ptr<rsdis_t2_interfaces::srv::Ecef2G::Request> request,
                           std::shared_ptr<rsdis_t2_interfaces::srv::Ecef2G::Response> response)
  {
    double r = std::sqrt(request->x * request->x + request->y * request->y);
    double Esq = kSemimajorAxis * kSemimajorAxis - kSemiminorAxis * kSemiminorAxis;
    double F = 54 * kSemiminorAxis * kSemiminorAxis * request->z * request->z;
    double G = r * r + (1 - kFirstEccentricitySquared) * request->z * request->z - kFirstEccentricitySquared * Esq;
    double C = (kFirstEccentricitySquared * kFirstEccentricitySquared * F * r * r) / std::pow(G, 3);
    double S = std::cbrt(1 + C + std::sqrt(C * C + 2 * C));
    double P = F / (3 * std::pow((S + 1 / S + 1), 2) * G * G);
    double Q = std::sqrt(1 + 2 * kFirstEccentricitySquared * kFirstEccentricitySquared * P);
    
    double r_0 = -(P * kFirstEccentricitySquared * r) / (1 + Q)
        + std::sqrt(0.5 * kSemimajorAxis * kSemimajorAxis * (1 + 1.0 / Q)
                - P * (1 - kFirstEccentricitySquared) * request->z * request->z / (Q * (1 + Q)) - 0.5 * P * r * r);
                
    double U = std::sqrt(std::pow((r - kFirstEccentricitySquared * r_0), 2) + request->z * request->z);
    double V = std::sqrt(std::pow((r - kFirstEccentricitySquared * r_0), 2) + (1 - kFirstEccentricitySquared) * request->z * request->z);
    double Z_0 = kSemiminorAxis * kSemiminorAxis * request->z / (kSemimajorAxis * V);
    
    response->altitude = U * (1 - kSemiminorAxis * kSemiminorAxis / (kSemimajorAxis * V));
    response->latitude = std::atan((request->z + kSecondEccentricitySquared * Z_0) / r) * (180.0 / M_PI);
    response->longitude = std::atan2(request->y, request->x) * (180.0 / M_PI);
    
    RCLCPP_INFO(this->get_logger(), "[ECEF2G] Convertido XYZ para GPS com sucesso.");
  }

  rclcpp::Service<rsdis_t2_interfaces::srv::DegToRad>::SharedPtr d2r_service_;
  rclcpp::Service<rsdis_t2_interfaces::srv::RadToDeg>::SharedPtr r2d_service_;
  rclcpp::Service<rsdis_t2_interfaces::srv::G2Ecef>::SharedPtr g2ecef_service_;
  rclcpp::Service<rsdis_t2_interfaces::srv::Ecef2G>::SharedPtr ecef2g_service_;
};

int main(int argc, char **argv)
{
  rclcpp::init(argc, argv);
  rclcpp::spin(std::make_shared<UGVServer>());
  rclcpp::shutdown();
  return 0;
}
